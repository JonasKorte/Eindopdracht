#!/bin/bash

echo "Opening Max..."
cd Max
open Eindopdracht.maxpat
cd ..

cd csdosc
npm start